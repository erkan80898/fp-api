#!/usr/bin/env fish

command go build ../../flxUpdater.go
command go build ../../flxDelister.go
command go build ../../flxStageCounter.go
